#include <iostream>
#include <vector>
using namespace std;

struct Node
{
	int distance;
	int Number;
	bool Visited;
	Node()
	{
		Visited = false;
		Number = -1;
		distance = INT32_MAX;
	}
};


ostream& operator << (ostream& Out, Node* N)
{
	Out << N->Number + 1 << " = " << N->distance << endl;
	return Out;
}

void MinHeapify(vector<Node*>& V, int Start, int End)
{
	int n = End - Start + 1;
	int Before = Start;
	for (int i = n / 2; i > 0; i--)
	{
		if (2 * i < n && V[2 * i + Before]->distance < V[i - 1 + Before]->distance)
		{
			swap(V[2 * i + Before], V[i - 1 + Before]);
		}
		if (2 * i - 1 < n && V[2 * i - 1 + Before]->distance < V[i - 1 + Before]->distance)
		{
			swap(V[2 * i - 1 + Before], V[i - 1 + Before]);
		}
	}
}


void ReadGrid(int** Grid, int n)
{
	while (1)
	{
		int x, y;
		int distance;
		cout << "Enter -1 To Finish " << endl;
		cout << "From ===> ";
		cin >> x;

		if (x == -1)
			return;
		x--;

		cout << "To ===> ";
		cin >> y;

		if (y == -1)
			return;
		y--;

		cout << "Distance ===> ";
		cin >> distance;

		Grid[x][y] = distance;
		system("cls");
	}
}


void Dijekstra(int** Grid, vector<Node*>& Vertices, int n)
{
	int Start;
	cout << "From Which Vertix ? ==> ";
	cin >> Start;
	Start--;
	vector<Node*> Ver;

	for (int i = 0; i < n; i++)
	{
		Node* N = new Node;
		N->Number = i;
		if (i == Start)
			N->distance = 0;
		Ver.push_back(N);
		Vertices.push_back(N);
	}
	int Limit = 0;
	while (Limit < n - 1)
	{
		MinHeapify(Ver, Limit, n - 1);
		Node* CurrentNode = Ver[Limit];
		if (!CurrentNode->Visited)
		{
			CurrentNode->Visited = true;
			for (int i = 0; i < n; i++)
			{
				if (Grid[CurrentNode->Number][i] != INT32_MAX && CurrentNode->distance != INT32_MAX && CurrentNode->distance + Grid[CurrentNode->Number][i] < Vertices[i]->distance)
				{
					Vertices[i]->distance = CurrentNode->distance + Grid[CurrentNode->Number][i];
				}
			}
		}
		Limit++;
	}
}


int main()
{
	int n;
	cout << "Enter # Vertices ==> ";
	cin >> n;
	int** Vertices = new int* [n];
	for (int i = 0; i < n; i++)
	{
		Vertices[i] = new int[n];
		for (int j = 0; j < n; j++)
		{
			Vertices[i][j] = INT32_MAX;
		}
	}

	ReadGrid(Vertices, n);

	vector<Node*> V;
	Dijekstra(Vertices, V, n);

	for (int i = 0; i < n; i++)
	{
		cout << V[i];
	}

	for (int i = 0; i < n; i++)
	{
		delete[] Vertices[i];
	}
	delete[] Vertices;
	return 0;
}