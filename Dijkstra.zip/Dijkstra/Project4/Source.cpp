#include <iostream>
using namespace std;
int main()
{
	int n;
	cin >> n;
	int X;
	int Max, Min;
	cin >> X;
	Max = X;
	Min = X;
	for (int i = 1; i < n; i++)
	{
		cin >> X;
		Max = max(X, Max);
		Min = min(X, Min);
	}
	cout << Max - Min; 
	return 0;
}